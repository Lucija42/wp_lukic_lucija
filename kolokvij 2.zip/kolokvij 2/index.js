let broj = prompt("Unesi jedan broj: ");
let rezultat = broj * 2;
alert("Unio si broj " + broj + ", a dva puta veći je: " + (broj * 2));
